<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" import="vn.codegym.product.*,java.util.List" %>
<% String base = request.getContextPath(); List<Product> products = (List<Product>) request.getAttribute("products"); %>
<!doctype html><html lang="vi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Quản lý sản phẩm</title><link rel="stylesheet" href="<%=base%>/style.css"></head>
<body><main><header><div><small>CODEGYM · FINAL EXAM</small><h1>Quản lý sản phẩm</h1><p>Danh mục hiện có: <%=products.size()%> sản phẩm</p></div><a class="button" href="<%=base%>/products/new">+ Thêm sản phẩm</a></header>
<div class="table-wrap"><table><thead><tr><th>ID</th><th>Tên sản phẩm</th><th>Giá (VND)</th><th>Số lượng</th><th>Thao tác</th></tr></thead><tbody>
<% if (products.isEmpty()) { %><tr><td colspan="5">Chưa có sản phẩm. Hãy thêm sản phẩm đầu tiên.</td></tr><% } %>
<% for (Product p : products) { %><tr><td><%=p.getId()%></td><td><%=Html.escape(p.getName())%></td><td><%=p.getPrice().toPlainString()%></td><td><%=p.getQuantity()%></td><td class="actions"><a href="<%=base%>/products/edit?id=<%=p.getId()%>">Sửa</a><form method="post" action="<%=base%>/products/delete" onsubmit="return confirm('Bạn có chắc muốn xóa sản phẩm này?');"><input type="hidden" name="csrf" value="<%=Html.escape(session.getAttribute("csrf"))%>"><input type="hidden" name="id" value="<%=p.getId()%>"><button class="danger" type="submit">Xóa</button></form></td></tr><% } %>
</tbody></table></div></main></body></html>
