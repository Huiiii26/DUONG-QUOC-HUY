<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" import="vn.codegym.product.*" %>
<% String base = request.getContextPath(); Product p = (Product)request.getAttribute("product"); boolean edit = p.getId() > 0; %>
<!doctype html><html lang="vi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title><%=edit ? "Sửa" : "Thêm"%> sản phẩm</title><link rel="stylesheet" href="<%=base%>/style.css"></head><body><main class="narrow"><a href="<%=base%>/products">← Danh sách sản phẩm</a><h1><%=edit ? "Sửa" : "Thêm"%> sản phẩm</h1>
<% if (request.getAttribute("error") != null) { %><p class="error" role="alert"><%=Html.escape(request.getAttribute("error"))%></p><% } %>
<form class="editor" method="post" action="<%=base%>/products/save"><input type="hidden" name="csrf" value="<%=Html.escape(session.getAttribute("csrf"))%>"><input type="hidden" name="id" value="<%=p.getId()%>">
<label>Tên sản phẩm<input name="name" maxlength="150" required value="<%=Html.escape(request.getAttribute("nameInput") != null ? request.getAttribute("nameInput") : p.getName())%>"></label>
<label>Giá (VND)<input name="price" type="number" min="0" max="9999999999999.99" step="0.01" required value="<%=Html.escape(request.getAttribute("priceInput") != null ? request.getAttribute("priceInput") : p.getPrice())%>"></label>
<label>Số lượng<input name="quantity" type="number" min="0" max="2147483647" step="1" required value="<%=Html.escape(request.getAttribute("quantityInput") != null ? request.getAttribute("quantityInput") : p.getQuantity())%>"></label>
<div class="actions"><button type="submit">Lưu sản phẩm</button><a href="<%=base%>/products">Hủy</a></div></form></main></body></html>
