package vn.codegym.product;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.UUID;

@WebServlet(urlPatterns = {"/products", "/products/*"}, loadOnStartup = 1)
public class ProductServlet extends HttpServlet {
    private final ProductDao dao = new ProductDao();
    @Override public void init() throws ServletException {
        try { Class.forName("com.mysql.cj.jdbc.Driver"); }
        catch (ClassNotFoundException e) { throw new ServletException("MySQL driver unavailable", e); }
    }
    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8"); resp.setCharacterEncoding("UTF-8");
        HttpSession session = req.getSession();
        if (session.getAttribute("csrf") == null) session.setAttribute("csrf", UUID.randomUUID().toString());
        try {
            String path = req.getPathInfo();
            if (path == null || path.equals("/")) {
                req.setAttribute("products", dao.findAll()); view(req, resp, "list");
            } else if (path.equals("/new")) {
                req.setAttribute("product", new Product(0, "", BigDecimal.ZERO, 0)); view(req, resp, "form");
            } else if (path.equals("/edit")) {
                Product p = dao.find(id(req));
                if (p == null) { resp.sendError(404); return; }
                req.setAttribute("product", p); view(req, resp, "form");
            } else resp.sendError(404);
        } catch (IllegalArgumentException e) { resp.sendError(400, "Invalid product ID"); }
        catch (SQLException e) { databaseError(req, resp, e); }
    }
    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8"); resp.setCharacterEncoding("UTF-8");
        HttpSession session = req.getSession(false);
        if (session == null || !java.util.Objects.equals(session.getAttribute("csrf"), req.getParameter("csrf"))) {
            resp.sendError(403); return;
        }
        try {
            String path = req.getPathInfo();
            if ("/delete".equals(path)) {
                if (!dao.delete(id(req))) { resp.sendError(404); return; }
            } else if ("/save".equals(path)) {
                long id = idOrZero(req.getParameter("id"));
                String name = req.getParameter("name");
                String priceText = req.getParameter("price");
                String quantityText = req.getParameter("quantity");
                req.setAttribute("nameInput", name); req.setAttribute("priceInput", priceText); req.setAttribute("quantityInput", quantityText);
                req.setAttribute("product", new Product(id, "", BigDecimal.ZERO, 0));
                Product p;
                try {
                    BigDecimal price = new BigDecimal(priceText);
                    int quantity = Integer.parseInt(quantityText);
                    if (name == null || name.isBlank() || name.strip().length() > 150 || price.signum() < 0 || price.scale() > 2
                            || price.compareTo(new BigDecimal("9999999999999.99")) > 0 || quantity < 0)
                        throw new IllegalArgumentException();
                    p = new Product(id, name.strip(), price, quantity);
                } catch (IllegalArgumentException | NullPointerException e) {
                    resp.setStatus(400); req.setAttribute("error", "Nhập tên 1–150 ký tự, giá không âm (tối đa 2 chữ số thập phân), số lượng nguyên không âm.");
                    view(req, resp, "form"); return;
                }
                if (id == 0) dao.insert(p);
                else if (!dao.update(p)) { resp.sendError(404); return; }
            } else { resp.sendError(404); return; }
            resp.sendRedirect(req.getContextPath() + "/products");
        } catch (IllegalArgumentException e) { resp.sendError(400, "Invalid product ID"); }
        catch (SQLException e) { databaseError(req, resp, e); }
    }
    private static long id(HttpServletRequest req) { long id = Long.parseLong(req.getParameter("id")); if (id <= 0) throw new IllegalArgumentException(); return id; }
    private static long idOrZero(String text) { if (text == null || text.isBlank() || text.equals("0")) return 0; long id = Long.parseLong(text); if (id < 0) throw new IllegalArgumentException(); return id; }
    private void view(HttpServletRequest req, HttpServletResponse resp, String name) throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/" + name + ".jsp").forward(req, resp);
    }
    private void databaseError(HttpServletRequest req, HttpServletResponse resp, SQLException e) throws ServletException, IOException {
        getServletContext().log("Product database error", e); resp.setStatus(500);
        view(req, resp, "error");
    }
}
