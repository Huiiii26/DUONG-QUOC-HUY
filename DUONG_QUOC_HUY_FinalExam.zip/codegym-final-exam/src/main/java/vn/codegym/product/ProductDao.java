package vn.codegym.product;

import java.sql.*;
import java.util.*;

public class ProductDao {
    private Connection connect() throws SQLException {
        return DriverManager.getConnection(env("DB_URL", "jdbc:mysql://localhost:3306/codegym_products?useUnicode=true&characterEncoding=UTF-8&serverTimezone=UTC"),
                env("DB_USER", "root"), env("DB_PASSWORD", ""));
    }
    private static String env(String key, String fallback) {
        String value = System.getenv(key);
        return value == null ? fallback : value;
    }
    public List<Product> findAll() throws SQLException {
        List<Product> products = new ArrayList<>();
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("SELECT id,name,price,quantity FROM products ORDER BY id DESC"); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) products.add(read(rs));
        }
        return products;
    }
    public Product find(long id) throws SQLException {
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("SELECT id,name,price,quantity FROM products WHERE id=?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? read(rs) : null; }
        }
    }
    public void insert(Product p) throws SQLException {
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("INSERT INTO products(name,price,quantity) VALUES(?,?,?)")) {
            values(ps, p); ps.executeUpdate();
        }
    }
    public boolean update(Product p) throws SQLException {
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("UPDATE products SET name=?,price=?,quantity=? WHERE id=?")) {
            values(ps, p); ps.setLong(4, p.getId()); return ps.executeUpdate() == 1;
        }
    }
    public boolean delete(long id) throws SQLException {
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("DELETE FROM products WHERE id=?")) {
            ps.setLong(1, id); return ps.executeUpdate() == 1;
        }
    }
    private static void values(PreparedStatement ps, Product p) throws SQLException {
        ps.setString(1, p.getName()); ps.setBigDecimal(2, p.getPrice()); ps.setInt(3, p.getQuantity());
    }
    private static Product read(ResultSet rs) throws SQLException {
        return new Product(rs.getLong("id"), rs.getString("name"), rs.getBigDecimal("price"), rs.getInt("quantity"));
    }
}
