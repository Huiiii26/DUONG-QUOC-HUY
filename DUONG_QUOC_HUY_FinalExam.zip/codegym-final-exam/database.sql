CREATE DATABASE IF NOT EXISTS codegym_products CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE codegym_products;
CREATE TABLE IF NOT EXISTS products (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(150) NOT NULL,
    price DECIMAL(15,2) NOT NULL CHECK (price >= 0),
    quantity INT NOT NULL CHECK (quantity >= 0)
);
-- Chạy dữ liệu mẫu một lần trên bảng mới.
INSERT INTO products(name,price,quantity) VALUES
('Bàn phím cơ',850000.00,12),('Chuột không dây',320000.00,25),('Màn hình 24 inch',2890000.00,8);
