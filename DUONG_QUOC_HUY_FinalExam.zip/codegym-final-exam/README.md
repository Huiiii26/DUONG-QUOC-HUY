# Quản lý sản phẩm — CodeGym Final Exam

Dự án Java Servlet + JSP + JDBC/MySQL, tổ chức MVC. Có danh sách, thêm, sửa, xóa với xác nhận; kiểm tra dữ liệu, PreparedStatement, đóng tài nguyên bằng try-with-resources, escape HTML và CSRF token.

## Môi trường

- JDK 17 trở lên, Maven 3.9 trở lên.
- Apache Tomcat 10.1 (Jakarta Servlet 6), MySQL 8.

## Chạy

1. Chạy `database.sql` trên MySQL (dữ liệu mẫu chỉ nhập một lần).
2. Đặt các biến môi trường cho tiến trình Tomcat: `DB_URL`, `DB_USER`, `DB_PASSWORD`. URL mặc định là `jdbc:mysql://localhost:3306/codegym_products?useUnicode=true&characterEncoding=UTF-8&serverTimezone=UTC`, user mặc định `root`, mật khẩu mặc định rỗng. Nên cấu hình user riêng có quyền SELECT/INSERT/UPDATE/DELETE trên database này.
3. Tại thư mục dự án chạy `mvn clean package`.
4. Chép `target/product-manager.war` vào `TOMCAT_HOME/webapps/`, khởi động Tomcat.
5. Mở `http://localhost:8080/product-manager/`.

## Kiểm tra thủ công

- Danh sách hiển thị dữ liệu mẫu và đủ ID, tên, giá, số lượng.
- Thêm sản phẩm tiếng Việt, giá có 2 chữ số thập phân, số lượng 0; kiểm tra bản ghi trong MySQL.
- Sửa thông tin, tải lại trang và xác nhận dữ liệu được lưu.
- Bấm Xóa rồi Hủy: giữ bản ghi; bấm Xóa rồi xác nhận: xóa bản ghi.
- Tên trống, giá âm, số lượng âm hoặc quá lớn phải bị từ chối.
- Tên có `<script>` chỉ hiển thị như văn bản.
- ID không hợp lệ trả 400; ID không tồn tại trả 404; lỗi MySQL hiển thị thông báo chung và ghi log server.

## Nộp bài

Đổi tên ZIP theo `[Mã_số_sinh_viên]_FinalExam.zip` khi biết mã học viên. ZIP chứa mã nguồn và database.sql. Chưa xuất bản hoặc nộp link công khai. Mã nguồn được chuẩn bị với sự hỗ trợ của OpenAI Codex; không sao chép từ dự án bên thứ ba.
